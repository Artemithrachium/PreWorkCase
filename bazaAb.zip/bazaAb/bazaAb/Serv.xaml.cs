﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bazaAb
{
    /// <summary>
    /// Логика взаимодействия для Serv.xaml
    /// </summary>
    public partial class Serv : Window
    {
        public Authorization authorization;
        public Serv(Authorization authorization)
        {
            InitializeComponent();
            this.authorization = authorization;
        }
  

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Main_Menu main = new Main_Menu();
            main.Show();
            this.Close();
        }

        private void Agreement_Work_Click(object sender, RoutedEventArgs e)
        {
            Frames.Content = new WinAgreement();

        }

        private void App_for_Connect_Click(object sender, RoutedEventArgs e)
        {
            Frames.Content = new WinApp_Connect();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bazaAb
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class AuthorizationPage : Window
    {
        public AuthorizationPage()
        {
            InitializeComponent();
        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(TextBoxLog.Text))
            {
                if (!String.IsNullOrEmpty(TextBoxPass.Text))
                {
                    IQueryable<Authorization> Авторизация_list = Connect.GetContext().Authorization.Where(p => p.Login == TextBoxLog.Text && p.Password == TextBoxPass.Text);
                    if (Авторизация_list.Count() == 1)
                    {
                        MessageBox.Show("Добро пожаловать, " + Авторизация_list.First().Login);
                        Serv окно_Пользователя = new Serv(Авторизация_list.First());
                        окно_Пользователя.Owner = this;
                        окно_Пользователя.Show();
                        this.Hide();
                    }
                    else MessageBox.Show("Неверный логин или пароль");

                }
            }
        }
    }
}

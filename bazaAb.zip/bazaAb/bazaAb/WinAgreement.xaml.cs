﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bazaAb
{
    /// <summary>
    /// Логика взаимодействия для WinAgreement.xaml
    /// </summary>
    public partial class WinAgreement : Page
    {
        public WinAgreement()
        {
            InitializeComponent();
            Agreement_void();
        }
        public void Agreement_void()
        {
           Connect.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            var massive = from Agreement in Connect.GetContext().Agreement
                               
                               join Services in Connect.GetContext().Services on Agreement.C__Agreement equals Services.ID_Services
                               join Status in Connect.GetContext().Status on Agreement.ID_Status equals Status.ID_Status
                               join Clients in Connect.GetContext().Clients on Agreement.C__Agreement equals Clients.C__Agreement
                               select new // Связи между затронутыми таблицами
                               {



                                   C_Agreement = Agreement.C__Agreement,
                                   SNP = Clients.Surname + " " + Clients.Name + " " + Clients.Patronymic,
                                   Phone_Num = Clients.Pnone_Num,
                                   Address = Clients.Address,
                                   Registration_Address = Clients.Registration_Address,
                                   Date_of_Registration = Agreement.Date_of_Registration,
                                   Title = Status.Title,
                                   Total_Coast = Services.Coast,
                                  
                               };
            if (!String.IsNullOrEmpty(Search.Text))
            {
                massive = massive.Where
                    (p => p.C_Agreement.Equals(Search.Text.ToLower().Trim()) &&
                    p.Phone_Num.Contains(Search.Text.ToLower().Trim())
                    && p.Address.Contains(Search.Text.ToLower().Trim())
                    && p.Date_of_Registration.Equals(Search.Text.ToLower().Trim())
                    && p.Registration_Address.Contains(Search.Text.ToLower().Trim()));
                    
            }; // Переменные для поиска

            DataGrid_Agreement.ItemsSource = massive.ToList(); //Обновление данных
        }




private void Change_Click(object sender, RoutedEventArgs e)
        {
            Button but= sender as Button;
            Сhange_Agreement window = new Сhange_Agreement(but.Tag);
            window.Show();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            {
                MessageBoxResult resbox = MessageBox.Show("Вы действительно хотите удалить запись?", "Удаление записи", MessageBoxButton.YesNo);

                if (resbox == MessageBoxResult.Yes)
                {

                    int id = Convert.ToInt32(TypeDescriptor.GetProperties(DataGrid_Agreement.SelectedItem)[0].GetValue(DataGrid_Agreement.SelectedItem));

                    Agreement product = Connect.GetContext().Agreement.Where(p => p.C__Agreement == id).First();
                    Connect.GetContext().Agreement.Remove(product);
                    Connect.GetContext().SaveChanges();
                    Agreement_void();
                }
            }
        }

        public class MyEmployee
        {
            public string Name { get; set; }
            public string Surname { get; set; }
            public string Patronimic { get; set; }
            public string DisplayName
            {
                get { return Surname + " " + Name + " " + Patronimic; }
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Agreement_void();
            
        }

        private void ComboBox_Selected(object sender, RoutedEventArgs e)
        {
            //switch (Sortirovka.SelectedIndex)
            //{
            //    case 0:
            //        DataGrid_Agreement = DataGrid_Agreement.OrderByDescending(p => p.Total_Coast).ToList();
            //        break;
            //    case 1:
            //        DataGrid_Agreement = DataGrid_Agreement.OrderBy(p => p.Total_Coast).ToList();
            //        break;
            //    case 2:
            //        Title = Title.OrderBy(p => p.Name).ToList();
            //        break;
            //    case 3:
            //        Title = Title.OrderByDescending(p => p.Surname).ToList();
            //        break;
            //}

        }
    }
}

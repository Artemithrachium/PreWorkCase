﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bazaAb
{
    /// <summary>
    /// Логика взаимодействия для Change_App_Connect.xaml
    /// </summary>
    public partial class Add_App_Connect : Window
    {
        
        public Add_App_Connect()
        {
            InitializeComponent();
           

        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {


            //        Connect.GetContext().App_on_for_Connect.Add(new App_on_for_Connect()
            //        {
            //            C__Agreement = Agreement_TextBlock_App_Connect.Text,
            //            //Name = text2.Text,
            //            Registration_Address = New_Address_App_Connect.Text,
            //            Date = Date_App_Connect.Date
            //            Title = Status_App_Connect.Text,

            //        });
            //        this.NavigationService.Navigate(new Uri("/admin.xaml", UriKind.Relative));
            //        Connect.GetContext().SaveChanges();
            //        MessageBox.Show("Успешно!");
        }
    }
}


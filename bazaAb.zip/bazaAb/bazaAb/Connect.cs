﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bazaAb
{
    internal class Connect
    {
        private static DB_Connect _context;
        public static DB_Connect GetContext()
        {
            if (_context == null)
                _context = new DB_Connect();
            return _context;
        }
    }
}

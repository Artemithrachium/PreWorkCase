﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bazaAb
{
    /// <summary>
    /// Логика взаимодействия для WinApp_Connect.xaml
    /// </summary>
    public partial class WinApp_Connect : Window
    {
        public WinApp_Connect()
        {
            InitializeComponent();
            AppConnect_void();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            AppConnect_void();
        }
        public void AppConnect_void()
        {
            Connect.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
            var massive = from App_on_for_Connect in Connect.GetContext().App_on_for_Connect
                          join Agreement in Connect.GetContext().Agreement on App_on_for_Connect.ID_App_Connect equals Agreement.C__Agreement

                          join Employer in Connect.GetContext().Employer on App_on_for_Connect.ID_Employer equals Employer.ID_Employer
                          join Status in Connect.GetContext().Status on App_on_for_Connect.ID_Status equals Status.ID_Status
                          join Clients in Connect.GetContext().Clients on Agreement.C__Agreement equals Clients.C__Agreement
                          select new // Связи между затронутыми таблицами
                          {
                              C_Agreement = Agreement.C__Agreement,
                              //SNP = Clients.Surname,Name,Patronimic,
                              Address = Clients.Address,
                              Date = App_on_for_Connect.Date,
                              Title = Status.Title,
                             
                          };
            if (!String.IsNullOrEmpty(Search_App.Text))
            {
                massive = massive.Where
                    (p => p.C_Agreement.Equals(Search_App.Text)
                    && p.Address.Contains(Search_App.Text)
                    && p.Title.Contains(Search_App.Text)
                    /* && p.SNP.Contains(Search.Text)*/); 
            } // Переменные для поиска

            DataGrid_App_Connect.ItemsSource = massive.ToList(); //Обновление данных
        }

        
        private void Комментарий_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            Add_App_Connect addWindow = new Add_App_Connect();
            addWindow.Owner = this;
            addWindow.Show();
        }
    }
    
}

